package com.nickwinsen.studybot.commands;

import com.nickwinsen.studybot.lavaplayer.GuildMusicManager;
import com.nickwinsen.studybot.lavaplayer.PlayerManager;
import com.nickwinsen.studybot.listeners.PomodoroTimer;
import com.sedmelluq.discord.lavaplayer.player.AudioPlayer;
import com.sedmelluq.discord.lavaplayer.track.AudioTrackInfo;
import net.dv8tion.jda.api.AccountType;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.*;
import net.dv8tion.jda.api.entities.Icon;
import net.dv8tion.jda.api.entities.channel.concrete.*;
import net.dv8tion.jda.api.entities.emoji.RichCustomEmoji;
import net.dv8tion.jda.api.entities.sticker.StickerPack;
import net.dv8tion.jda.api.entities.sticker.StickerSnowflake;
import net.dv8tion.jda.api.entities.sticker.StickerUnion;
import net.dv8tion.jda.api.events.guild.GuildReadyEvent;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.IEventManager;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.commands.Command;
import net.dv8tion.jda.api.interactions.commands.OptionMapping;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.CommandData;
import net.dv8tion.jda.api.interactions.commands.build.Commands;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;
import net.dv8tion.jda.api.managers.AudioManager;
import net.dv8tion.jda.api.managers.DirectAudioController;
import net.dv8tion.jda.api.managers.Presence;
import net.dv8tion.jda.api.requests.GatewayIntent;
import net.dv8tion.jda.api.requests.RestAction;
import net.dv8tion.jda.api.requests.restaction.*;
import net.dv8tion.jda.api.sharding.ShardManager;
import net.dv8tion.jda.api.utils.cache.CacheFlag;
import net.dv8tion.jda.api.utils.cache.CacheView;
import net.dv8tion.jda.api.utils.cache.SnowflakeCacheView;
import okhttp3.OkHttpClient;
import org.jetbrains.annotations.NotNull; //everything about a function containing this warning should not be null.
import java.util.*;
import java.util.concurrent.BlockingQueue;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledExecutorService;

import com.sedmelluq.discord.lavaplayer.track.AudioTrack;

public class CommandManager extends ListenerAdapter {


    ArrayList<String> todoList = new ArrayList<>();

    int tdcount = 0;
    private JDA jda;

    @Override
    public void onSlashCommandInteraction(@NotNull SlashCommandInteractionEvent event) {
        super.onSlashCommandInteraction(event);
        final JDA jda = new JDA() {
            @Override
            public Status getStatus() {
                return null;
            }

            @Override
            public EnumSet<GatewayIntent> getGatewayIntents() {
                return null;
            }

            @Override
            public EnumSet<CacheFlag> getCacheFlags() {
                return null;
            }

            @Override
            public boolean unloadUser(long l) {
                return false;
            }

            @Override
            public long getGatewayPing() {
                return 0;
            }

            @Override
            public JDA awaitStatus(Status status, Status... statuses) throws InterruptedException {
                return null;
            }

            @Override
            public int cancelRequests() {
                return 0;
            }

            @Override
            public ScheduledExecutorService getRateLimitPool() {
                return null;
            }

            @Override
            public ScheduledExecutorService getGatewayPool() {
                return null;
            }

            @Override
            public ExecutorService getCallbackPool() {
                return null;
            }

            @Override
            public OkHttpClient getHttpClient() {
                return null;
            }

            @Override
            public DirectAudioController getDirectAudioController() {
                return null;
            }

            @Override
            public void setEventManager(IEventManager iEventManager) {

            }

            @Override
            public void addEventListener(Object... objects) {

            }

            @Override
            public void removeEventListener(Object... objects) {

            }

            @Override
            public List<Object> getRegisteredListeners() {
                return null;
            }

            @Override
            public RestAction<List<Command>> retrieveCommands(boolean b) {
                return null;
            }

            @Override
            public RestAction<Command> retrieveCommandById(String s) {
                return null;
            }

            @Override
            public RestAction<Command> upsertCommand(CommandData commandData) {
                return null;
            }

            @Override
            public CommandListUpdateAction updateCommands() {
                return null;
            }

            @Override
            public CommandEditAction editCommandById(String s) {
                return null;
            }

            @Override
            public RestAction<Void> deleteCommandById(String s) {
                return null;
            }

            @Override
            public GuildAction createGuild(String s) {
                return null;
            }

            @Override
            public RestAction<Void> createGuildFromTemplate(String s, String s1, Icon icon) {
                return null;
            }

            @Override
            public CacheView<AudioManager> getAudioManagerCache() {
                return null;
            }

            @Override
            public SnowflakeCacheView<User> getUserCache() {
                return null;
            }

            @Override
            public List<Guild> getMutualGuilds(User... users) {
                return null;
            }

            @Override
            public List<Guild> getMutualGuilds(Collection<User> collection) {
                return null;
            }

            @Override
            public CacheRestAction<User> retrieveUserById(long l) {
                return null;
            }

            @Override
            public SnowflakeCacheView<Guild> getGuildCache() {
                return null;
            }

            @Override
            public Set<String> getUnavailableGuilds() {
                return null;
            }

            @Override
            public boolean isUnavailable(long l) {
                return false;
            }

            @Override
            public SnowflakeCacheView<Role> getRoleCache() {
                return null;
            }

            @Override
            public SnowflakeCacheView<ScheduledEvent> getScheduledEventCache() {
                return null;
            }

            @Override
            public SnowflakeCacheView<PrivateChannel> getPrivateChannelCache() {
                return null;
            }

            @Override
            public CacheRestAction<PrivateChannel> openPrivateChannelById(long l) {
                return null;
            }

            @Override
            public SnowflakeCacheView<RichCustomEmoji> getEmojiCache() {
                return null;
            }

            @Override
            public RestAction<StickerUnion> retrieveSticker(StickerSnowflake stickerSnowflake) {
                return null;
            }

            @Override
            public RestAction<List<StickerPack>> retrieveNitroStickerPacks() {
                return null;
            }

            @Override
            public IEventManager getEventManager() {
                return null;
            }

            @Override
            public SelfUser getSelfUser() {
                return null;
            }

            @Override
            public Presence getPresence() {
                return null;
            }

            @Override
            public ShardInfo getShardInfo() {
                return null;
            }

            @Override
            public String getToken() {
                return null;
            }

            @Override
            public long getResponseTotal() {
                return 0;
            }

            @Override
            public int getMaxReconnectDelay() {
                return 0;
            }

            @Override
            public void setAutoReconnect(boolean b) {

            }

            @Override
            public void setRequestTimeoutRetry(boolean b) {

            }

            @Override
            public boolean isAutoReconnect() {
                return false;
            }

            @Override
            public boolean isBulkDeleteSplittingEnabled() {
                return false;
            }

            @Override
            public void shutdown() {

            }

            @Override
            public void shutdownNow() {

            }

            @Override
            public AccountType getAccountType() {
                return null;
            }

            @Override
            public RestAction<ApplicationInfo> retrieveApplicationInfo() {
                return null;
            }

            @Override
            public JDA setRequiredScopes(Collection<String> collection) {
                return null;
            }

            @Override
            public String getInviteUrl(Permission... permissions) {
                return null;
            }

            @Override
            public String getInviteUrl(Collection<Permission> collection) {
                return null;
            }

            @Override
            public ShardManager getShardManager() {
                return null;
            }

            @Override
            public RestAction<Webhook> retrieveWebhookById(String s) {
                return null;
            }

            @Override
            public SnowflakeCacheView<StageChannel> getStageChannelCache() {
                return null;
            }

            @Override
            public SnowflakeCacheView<ThreadChannel> getThreadChannelCache() {
                return null;
            }

            @Override
            public SnowflakeCacheView<Category> getCategoryCache() {
                return null;
            }

            @Override
            public SnowflakeCacheView<TextChannel> getTextChannelCache() {
                return null;
            }

            @Override
            public SnowflakeCacheView<NewsChannel> getNewsChannelCache() {
                return null;
            }

            @Override
            public SnowflakeCacheView<VoiceChannel> getVoiceChannelCache() {
                return null;
            }

            @Override
            public SnowflakeCacheView<ForumChannel> getForumChannelCache() {
                return null;
            }
        };
        String command = event.getName();
        if (command.equals("play")) {
            final GuildMusicManager gmm = PlayerManager.getInstance().getMusicManager(event.getGuild());
            final AudioPlayer audioPlayer = gmm.audioPlayer;
            final BlockingQueue<AudioTrack> queue = gmm.scheduler.queue;
            event.deferReply().queue();
            OptionMapping messageOption = event.getOption("title");
            String title = messageOption.getAsString();
            if (!event.getMember().getVoiceState().inAudioChannel()) {
                event.getChannel().sendMessage("You must be in a voice channel for me to play you music!").queue();
            }
            if (!event.getGuild().getSelfMember().getVoiceState().inAudioChannel()) {
                final AudioManager audioManager = event.getGuild().getAudioManager();
                final VoiceChannel memberChannel = (VoiceChannel) event.getMember().getVoiceState().getChannel();

                audioManager.openAudioConnection(memberChannel);
            }
            String link = title;
            if (!isUrl(link)) {
                link = "ytsearch:" + link + "audio";

            } //TODO: error here, need to find out how to get this working. Links work though // FIXED
            PlayerManager.getInstance().loadAndPlay(event.getGuildChannel().asTextChannel(), link);
//            numQueued[0]++;
            event.getHook().sendMessage("Track queued!").queue();

        } else if (command.equals("tdadd")) {
            OptionMapping messageOption = event.getOption("task");
            String title = messageOption.getAsString();
            todoList.add(title);
            tdcount++;
            event.reply("You have added " + title + " to your To-Do List in position: " + tdcount + " !").queue();
        } else if (command.equals("tdremove")) {
            if (!todoList.isEmpty()) {
                OptionMapping numberOption = event.getOption("toremove");
                int x = numberOption.getAsInt();
                x--;
                todoList.remove(x);
            } else {
                event.reply("The todolist is empty").queue();
            }
            event.reply("The task has been removed from your to-do list.").queue();
        } else if (command.equals("tddisplay")) {
            if (!todoList.isEmpty()) {
                String tdreply = "";
                for (int i = 0; i < todoList.size(); i++) {
                    tdreply += "**```" + (i + 1) + ". " + todoList.get(i) + "```**\n";
                }
                event.reply(tdreply).queue();
            }
            event.reply("The todolist is empty").queue();


        }
        if (command.equals("pomodoro")) {
            //creates a pomodoro timer that will dm the user at specified intervals.
            this.jda = jda;
            OptionMapping worklength = event.getOption("worklen");
            OptionMapping breaklength = event.getOption("breaklen");
            int x, y = 0;
            User user = event.getUser();
            x = worklength.getAsInt();
            y = breaklength.getAsInt();
            PomodoroTimer timer = new PomodoroTimer(jda, user, x, y);
            timer.start();
            event.reply("done").queue();
        }
        else if (command.equals("tdcomplete")) {
            event.deferReply().queue();
            event.getHook().sendMessage("Congratulations, " + event.getUser().getAsMention() + "! You have completed your " + tdcount + " tasks!").queue();
        } else if (command.equals("stop")) {
            if (!event.getMember().getVoiceState().inAudioChannel()) {
                event.getChannel().sendMessage("You need to be in a voice channel for this command to work.").queue();
                return;
            }

            if (!event.getGuild().getSelfMember().getVoiceState().inAudioChannel()) {
                event.getChannel().sendMessage("I need to be in a voice channel or I need to be playing music for this command to work.").queue();
                return;
            }

            if (event.getMember().getVoiceState().getChannel().equals(event.getGuild().getSelfMember().getVoiceState().getChannel())) {
                PlayerManager.getInstance().getMusicManager(event.getGuild()).scheduler.player.stopTrack();
                PlayerManager.getInstance().getMusicManager(event.getGuild()).scheduler.queue.clear();
                event.getGuild().getAudioManager().closeAudioConnection();
                event.reply("The player has been stopped and the queue has been cleared.").queue();
            }


        } else if (command.equals("skip")) {
            final GuildMusicManager musicManager = PlayerManager.getInstance().getMusicManager(event.getGuild());
            final AudioPlayer audioPlayer = musicManager.audioPlayer;
            final BlockingQueue<AudioTrack> queue = musicManager.scheduler.queue;

            musicManager.scheduler.nextTrack();
            event.reply("Now playing **`" + musicManager.audioPlayer.getPlayingTrack().getInfo().title + "`** by **`" + musicManager.audioPlayer.getPlayingTrack().getInfo().author + "`**.").queue();
        } else if (command.equals("queue")) {
            final GuildMusicManager musicManager = PlayerManager.getInstance().getMusicManager(event.getGuild());
            final BlockingQueue<AudioTrack> queue = musicManager.scheduler.queue;

            if (queue.isEmpty()) {
                event.getChannel().sendMessage("The queue is currently empty").queue();
                return;
            }

            final int trackCount = Math.min(queue.size(), 20);
            final List<AudioTrack> trackList = new ArrayList<>(queue);
            event.getChannel().sendMessage("**Current Queue:**\n");
            String response = "";
            for (int i = 0; i < trackCount; i++) {
                final AudioTrack track = trackList.get(i);
                final AudioTrackInfo info = track.getInfo();
                response += (i + 1) + ". " + String.valueOf(info.title) + " by " + String.valueOf(info.author) + "\n";
            }
            event.reply(response).queue();
        } else if (command.equals("current")) {
            final GuildMusicManager gmm = PlayerManager.getInstance().getMusicManager(event.getGuild());
            final AudioPlayer audioPlayer = gmm.audioPlayer;
            if (audioPlayer.getPlayingTrack() == null) {
                event.reply("There is currently no track playing");
            }
            String title = audioPlayer.getPlayingTrack().getInfo().title;
            String author = audioPlayer.getPlayingTrack().getInfo().author;

            event.reply("Now playing: " + title + "by" + author + "!").queue();
        }
    }


    //registering commands
    //Guild commands - instantly updates, there is a max of 100
    //you can register commands to specific servers, if(event.getGuild().getIdLong() == idL){ my server has different command. }
    //
    @Override
    public void onGuildReady(GuildReadyEvent event) {
        super.onGuildReady(event);
        ArrayList<CommandData> commandData = new ArrayList<>();
        commandData.add(Commands.slash("welcome", "Study bot will welcome you to the server"));
        commandData.add(Commands.slash("roles", "Displays roles on the server"));
        //command to repeat what the user tells it
        OptionData option2 = new OptionData(OptionType.STRING, "title", "The link or title of the video you would like to play.", true);
        OptionData option3 = new OptionData(OptionType.STRING, "task", "The task you would like to add to your to-do list.", true);
        OptionData option4 = new OptionData(OptionType.INTEGER, "toremove", "The number you would like to remove from your list.", true);
        OptionData worklen = new OptionData(OptionType.INTEGER, "worklen", "worklen", true);
        OptionData breaklen = new OptionData(OptionType.INTEGER, "breaklen", "breaklen", true);
        commandData.add(Commands.slash("queue", "Displays the current music queue"));
        commandData.add(Commands.slash("stop", "Deletes the queue and makes the bot leave."));
        commandData.add(Commands.slash("skip", "Skips the current song."));
        commandData.add(Commands.slash("play", "Enter a track you would like the bot to play!").addOptions(option2));
        commandData.add(Commands.slash("tdremove", "Removes an event from your todolist.").addOptions(option4));
        commandData.add(Commands.slash("tdadd", "Adds an event to your todolist.").addOptions(option3));
        commandData.add(Commands.slash("tddisplay", "Displays your todolist."));
       commandData.add(Commands.slash("pomodoro", "Creates a pomodoro timer, which will mention you to take breaks periodically.").addOptions(worklen, breaklen));
        commandData.add(Commands.slash("tdcomplete", "Celebrates you completing your todolist!"));
        commandData.add(Commands.slash("current", "Displays current track"));

        event.getGuild().updateCommands().addCommands(commandData).queue();
    }

    public boolean isUrl(String url) {
        try {
            new URI(url);

            return true;
        } catch (URISyntaxException e) {
            return false;
        }
    }

}

//    public static boolean isTimer1(){
//        JDA jda = new JDA() ;
//        TextChannel textChannel = jda.getTextChannelById("1056045795234807820");
//        while(true) {
//            if ((secondsIncrement % 1500 == 0 || secondsIncrement % 1800 == 0 || secondsIncrement %2 == 0) && textChannel.canTalk()) {
//                textChannel.sendMessage(jda.getUserById(useridpomS).getAsMention() + " Pomodoro event!");
//            }
//            return false;
//        }
//    }



//    public static void runTimer(){
//
//        timer.schedule(task, 0, 1000);
//    }
//
//    public static void stopTimer(){
//        timer.cancel();
//    }
//}


  // works when you add your bot to a server when it is already loaded
//    @Override
//    public void onGuildJoin(GuildJoinEvent event) {
//        super.onGuildJoin(event);
//        ArrayList<CommandData> commandData = new ArrayList<>();
//        commandData.add(Commands.slash("welcome", "Study bot will welcome you to the server"));
//        commandData.add(Commands.slash("roles", "Displays roles on the server"));
//        OptionData option1 = new OptionData(OptionType.STRING, "message", "The message you want the bot to say", true);
//        commandData.add(Commands.slash("say", "Make the bot say a message").addOptions(option1));
//        event.getGuild().updateCommands().addCommands(commandData).queue();
//    }

    //global commands - up to an hour to update, but you have no limit on them - to register as a global, you have to register them in your JDA

//    @Override
//    public void onReady(ReadyEvent event) {
//        super.onReady(event);
//        ArrayList<CommandData> commandData = new ArrayList<>();
//        commandData.add(Commands.slash("welcome", "Study bot will welcome you to the server"));
//        event.getJDA().updateCommands().addCommands(commandData).queue();
//    }

