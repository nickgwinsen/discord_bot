package com.nickwinsen.studybot.listeners;

import net.dv8tion.jda.api.entities.User;
import net.dv8tion.jda.api.events.guild.GuildJoinEvent;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.events.message.react.MessageReactionAddEvent;
import net.dv8tion.jda.api.interactions.commands.build.Commands;
import org.jetbrains.annotations.NotNull;

import java.util.Timer;
import java.util.TimerTask;

public class EventListener extends ListenerAdapter{

    @Override
    public void onMessageReactionAdd(@NotNull MessageReactionAddEvent event){

         User user = event.getUser(); //gets user that fired this event
         String emoji = event.getReaction().getEmoji().getAsReactionCode();
         String channelMention = event.getChannel().getAsMention();
         String jumpLink = event.getJumpUrl();

         String message = user.getAsTag() + " reacted to a message with " + emoji + " in " + channelMention + ": " + jumpLink;
         event.getGuild().getDefaultChannel().asStandardGuildMessageChannel().sendMessage(message).queue();
    }

    @Override
    public void onGuildJoin(GuildJoinEvent event) {
        super.onGuildJoin(event);
        event.getGuild().getDefaultChannel().asStandardGuildMessageChannel().sendMessage("Welcome to the server!").queue();
    }

    @Override
    public void onMessageReceived(MessageReceivedEvent event) { //requires gateway intent - finish tomorrow
        super.onMessageReceived(event);
        String message = event.getMessage().getContentRaw();
        if (message.contains("hey guys")) {
            event.getChannel().sendMessage("hey dudes.").queue();
        }
    }



} // cache notes: *******************************
    //some events may require a cache of the users that are using the bot for the event to fire: e.g a user updates their online status and you want the bot to say a message.
    //builder.setMemberCachePolicy(MemberCachePolicy.ALL) = cache all users that use the bot. ALL users in ALL servers that your bot is added to. There are more options.
    // ALL causes lazy loading, which does it slowly over time.
    //TO FIX: builder.setChunkingFilter(ChunkingFilter.ALL) = chunking.ALL forces your bot to cache all users on startup.
    //you have to determine what you want to save about the user in the cache. You can cache activity, online status, roles they have, voice state, etc
    //rest action:
    //you can retrieve users in a different way. event.getJDA().retrieveUserById() avoid queueing if you can. in doing this, we don't know when the queue will finish.
    // if you want to retrieve information through this method, you can do it through a callback function (user - > getID()
    //get needs a cache
    //retrieve does not need a cache, but requires a rest action

    // slash commands, you  can create a command manager, this section will cover basic command use

