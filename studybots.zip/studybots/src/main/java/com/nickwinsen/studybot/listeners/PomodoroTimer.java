package com.nickwinsen.studybot.listeners;

import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.entities.User;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class PomodoroTimer {

    private final JDA jda; // bot's jda instance
    private final User user;

    private final int worklen;
    public boolean started;
    private final int breaklen;
    private final ScheduledExecutorService scheduler;

    public PomodoroTimer(JDA jda, User user, int pomodoroLength, int breakLength) {
        this.jda = jda;
        this.user = user;
        this.worklen = pomodoroLength;
        this.breaklen = breakLength;
        this.scheduler = Executors.newSingleThreadScheduledExecutor();
    }

    public void start() {
        scheduler.schedule(this::runPomodoro, worklen, TimeUnit.MINUTES);
        System.out.println("started." + user);
    }

    private void runPomodoro() {
        user.openPrivateChannel().queue(channel -> channel.sendMessage("Hey," + user.getAsMention() + "! Sit back, relax, and take a break!\nhttps://tenor.com/view/chillax-trygve-chill-relax-trygve-chill-gif-24498498").queue());
        scheduler.schedule(this::runBreak, breaklen, TimeUnit.MINUTES);
    }

    private void runBreak() {
        user.openPrivateChannel().queue(channel -> channel.sendMessage("Hey, " + user.getAsMention() + "! Get back to work!\nhttps://tenor.com/view/back-to-work-getting-back-to-work-gif-14405767").queue());
        scheduler.schedule(this::runPomodoro, worklen, TimeUnit.MINUTES);
    }
}
