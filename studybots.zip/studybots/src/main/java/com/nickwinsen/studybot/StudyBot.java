package com.nickwinsen.studybot;
import com.fasterxml.jackson.databind.ser.std.StdKeySerializers;
import com.nickwinsen.studybot.commands.CommandManager;
import com.nickwinsen.studybot.lavaplayer.AudioPlayerSendHandler;
import com.nickwinsen.studybot.listeners.EventListener;
import com.sedmelluq.discord.lavaplayer.player.AudioPlayer;
import com.sedmelluq.discord.lavaplayer.player.AudioPlayerManager;
import com.sedmelluq.discord.lavaplayer.player.DefaultAudioPlayerManager;
import com.sedmelluq.discord.lavaplayer.source.AudioSourceManagers;
import com.sedmelluq.discord.lavaplayer.track.playback.NonAllocatingAudioFrameBuffer;
import io.github.cdimascio.dotenv.Dotenv;
import net.dv8tion.jda.api.OnlineStatus;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.interactions.commands.Command;
import net.dv8tion.jda.api.requests.GatewayIntent;
import net.dv8tion.jda.api.sharding.DefaultShardManagerBuilder;
import net.dv8tion.jda.api.sharding.ShardManager;

import javax.security.auth.login.LoginException;
import java.net.URI;
import java.net.URISyntaxException;

public class StudyBot {

    private final Dotenv privToken;
    private final ShardManager shardManager;
    public boolean isUrl(String url){
        try{
            new URI(url);
            return true;
        } catch (URISyntaxException e){
            return false;
        }
    }

    public StudyBot() throws LoginException {
        privToken = Dotenv.configure().load();
        String token = getPrivToken().get("TOKEN");

        DefaultShardManagerBuilder builder = DefaultShardManagerBuilder.createDefault(token);
        builder.setStatus(OnlineStatus.ONLINE);
        builder.setActivity(Activity.listening("your next command!"));
//        builder.enableIntents(GatewayIntent.MESSAGE_CONTENT);
        builder.enableIntents(GatewayIntent.GUILD_MEMBERS, GatewayIntent.MESSAGE_CONTENT); // gives permissions to bot to react to things happening with server members
        builder.enableIntents(GatewayIntent.GUILD_MESSAGES); //gives permission to bot to give reactions to the messages sent in the server
        shardManager = builder.build();

        //register listeners
        shardManager.addEventListener(new EventListener());
        shardManager.addEventListener(new CommandManager());
    }
    public Dotenv getPrivToken(){
        return privToken;
    }
    public ShardManager getShardManager() {
        return shardManager;
    }

    public static void main(String[] args) {
        final AudioPlayerManager playerManager = new DefaultAudioPlayerManager();
        playerManager.getConfiguration().setFrameBufferFactory(NonAllocatingAudioFrameBuffer::new);
        AudioSourceManagers.registerRemoteSources(playerManager);
        final AudioPlayer player = playerManager.createPlayer();
        try {
            StudyBot bot = new StudyBot();
        } catch (LoginException e) {
            System.out.println("ERROR: Bot token is invalid");
        }
    }
}

